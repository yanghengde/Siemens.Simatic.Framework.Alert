﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using System.Linq;

using Siemens.Simatic.Platform.Core;
using Siemens.Simatic.Platform.Common;
using Siemens.Simatic.KPI.Common;
using Siemens.Simatic.KPI.BusinessLogic;
using System.Collections;
using Siemens.Simatic.Wechat.Enums;
using Siemens.Simatic.Wechat.BusinessLogic;
using Siemens.Simatic.Wechat.BusinessLogic.DefaultImpl;
using Siemens.Simatic.Wechat.Common;
using System.Drawing;

namespace Siemens.Simatic.Email.Service
{
    public class EmailService : MainService
    {
        private string SenderName;//from
        private string SenderUser; //add by wesley@20130508
        private string SenderPassword;
        private string SmtpServer;
        private string SmtpPort;

        private string corpid = ConfigurationManager.AppSettings["corpid"];
        private string corpsecret = ConfigurationManager.AppSettings["corpsecret"];

        //
        private ICO_PRM_EVENT_LOGBO _co_PRM_EVENT_LOGBO;
        private ICV_PRM_EVENT_LOGBO _cv_PRM_EVENT_LOGBO;

        private ICV_PRM_EVENT_TYPE_GRP_MAPBO _cv_PRM_EVENT_TYPE_GRP_MAPBO;
        private ICV_PRM_NOTI_GROUP_DETAILBO _cv_PRM_NOTI_GROUP_DETAILBO;

        private ICO_BSC_EMAILBO _co_BSC_EMAILBO;

        private ICV_WECHAT_NOTIBO _cv_WECHAT_NOTIBO;
        private ICO_WECHAT_NOTIBO _co_WECHAT_NOTIBO;

        public EmailService(MesLog mesLog)
            : this("EmailProcessTimer", mesLog)
        {
        }

        public EmailService(string name, MesLog mesLog)
            : base(name, mesLog)
        {
            try
            {
                _co_PRM_EVENT_LOGBO = ObjectContainer.BuildUp<ICO_PRM_EVENT_LOGBO>();
                _cv_PRM_EVENT_LOGBO = ObjectContainer.BuildUp<ICV_PRM_EVENT_LOGBO>();

                _cv_PRM_EVENT_TYPE_GRP_MAPBO = ObjectContainer.BuildUp<ICV_PRM_EVENT_TYPE_GRP_MAPBO>();
                _cv_PRM_NOTI_GROUP_DETAILBO = ObjectContainer.BuildUp<ICV_PRM_NOTI_GROUP_DETAILBO>();
                //
                _co_BSC_EMAILBO = ObjectContainer.BuildUp<ICO_BSC_EMAILBO>();

                _cv_WECHAT_NOTIBO = ObjectContainer.BuildUp<ICV_WECHAT_NOTIBO>();
                _co_WECHAT_NOTIBO = new CO_WECHAT_NOTIBO(corpid, corpsecret);
            }
            catch (Exception e)
            {
                // need EmailService instance to send email only.
            }

            this.SenderUser = ConfigurationManager.AppSettings["SenderUser"];
            this.SenderPassword = ConfigurationManager.AppSettings["SenderPwd"];
            this.SenderName = ConfigurationManager.AppSettings["SenderAccount"];
            this.SmtpServer = ConfigurationManager.AppSettings["SmtpServer"];
            this.SmtpPort = ConfigurationManager.AppSettings["SmtpPort"];
        }

        protected override object GetReadyData()
        {
            try
            {
                return new object();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        protected override bool Execute(object readyData)
        {
            try
            {
                if (readyData == null) return false;

                string returnMessage = string.Empty;
                bool isSent = false;
                //
                #region CV_PRM_EVENT_LOG
                CV_PRM_EVENT_LOGQueryParam qp = new CV_PRM_EVENT_LOGQueryParam();
                qp.IsFinished = false;
                IList<CV_PRM_EVENT_LOG> events = _cv_PRM_EVENT_LOGBO.GetEntities(qp);
                foreach (CV_PRM_EVENT_LOG eventLog in events)
                {
                    string toList = string.Empty;
                    isSent = false;
                    //
                    IList<CV_PRM_EVENT_TYPE_GRP_MAP> grpMaps = _cv_PRM_EVENT_TYPE_GRP_MAPBO.GetEntities(eventLog.EventTypeID.Value);
                    foreach (CV_PRM_EVENT_TYPE_GRP_MAP grpMap in grpMaps)
                    {
                        if (!grpMap.NotiEmail.Value) continue;

                        IList<CV_PRM_NOTI_GROUP_DETAIL> grpDtls = _cv_PRM_NOTI_GROUP_DETAILBO.GetEntitiesByGroup(grpMap.NotiGroupID.Value);
                        foreach (CV_PRM_NOTI_GROUP_DETAIL grpDtl in grpDtls)
                        {
                            if (!string.IsNullOrEmpty(grpDtl.EmailAddress))
                                toList += string.Format("{0},", grpDtl.EmailAddress);
                        }
                    }
                    //
                    toList = toList.TrimEnd(',');
                    //
                    if (string.IsNullOrEmpty(toList))
                    {
                        eventLog.NotifiedCnt += 1;
                        // 
                        if (eventLog.NotifiedCnt >= eventLog.NotiCnt) eventLog.IsFinished = true; else eventLog.IsFinished = false;
                        //
                        isSent = true;
                    }
                    else
                    {
                        string to = toList.TrimEnd(',');
                        string cc = string.Empty;
                        string bcc = string.Empty;
                        string subject = eventLog.EventBrief;
                        string body = eventLog.EventContent;
                        body = System.Web.HttpUtility.HtmlDecode(body);
                        //
                        try
                        {
                            //MSM to do...
                            // Send mail without Ssl
                            isSent = MailHelper.SendNetMail(to, cc, bcc, subject, body, eventLog.Attachments, this.SenderName, this.SenderUser, this.SenderPassword, this.SmtpServer, this.SmtpPort, false);
                            //

                            eventLog.NotifiedCnt += 1;
                            if (eventLog.NotifiedCnt >= eventLog.NotiCnt) eventLog.IsFinished = true; else eventLog.IsFinished = false;

                        }
                        catch (Exception ex)
                        {
                            returnMessage += ex.Message + "|";
                        }
                    }
                    //
                    if (isSent)
                    {
                        _co_PRM_EVENT_LOGBO.Notified(eventLog.EventLogID.Value, eventLog.NotifiedCnt.Value, eventLog.IsFinished.Value);
                    }
                }
                #endregion
                //
                #region CO_BSC_EMAIL
                IList<CO_BSC_EMAIL> emails = _co_BSC_EMAILBO.GetEntitiesToSend();
                //
                foreach (CO_BSC_EMAIL email in emails)
                {
                    if (email.EmailType == 0)//邮件发送
                    {
                        isSent = false;
                        //
                        string to = email.EmailTo;
                        string cc = email.EmailCc;
                        string bcc = email.EmailBcc;
                        string subject = email.EmailSubject;
                        string body = email.EmailContent;
                        body = System.Web.HttpUtility.HtmlDecode(body);
                        //
                        try
                        {
                            isSent = MailHelper.SendNetMail(to, cc, bcc, subject, body, email.Attachments, this.SenderName, this.SenderUser, this.SenderPassword, this.SmtpServer, this.SmtpPort, false);
                            email.ErrorMsg = string.Empty;
                        }
                        catch (Exception ex)
                        {
                            email.ErrorMsg = ex.Message;
                            //
                            _mesLog.LogException("Exception: " + returnMessage + ". StackTree: " + ex.Message + Environment.NewLine + ex.StackTrace, this.Name + ".Execute()", true);
                        }
                        //
                    }
                    else if (email.EmailType == 1)//微信发送
                    {
                        _co_WECHAT_NOTIBO.Gettoken(corpid, corpsecret);

                        IList<CV_WECHAT_NOTI> notiList = _cv_WECHAT_NOTIBO.GetEntities(new CV_WECHAT_NOTI { AlertID = email.ObjectID });
                        if (notiList != null && notiList.Count > 0)
                        {
                            foreach (CV_WECHAT_NOTI noti in notiList)
                            {
                                if (email.Format == WechatFormat.IMAGE)
                                {
                                    Rectangle rec = new Rectangle(noti.BrowserWidth.Value, noti.BrowserHeight.Value, noti.ThumbnailWidth.Value, noti.ThumbnailHeight.Value);
                                    ReturnValue rv = _co_WECHAT_NOTIBO.SendImage(rec, noti.AgentID.Value, email.EmailSubject, email.EmailContent.Replace("<table border='8',cellspacing='0',cellpadding='0'>", noti.TableStyle), noti.ID.Value.ToString(), false);
                                    email.ErrorMsg = "SendImage: Success=[" + rv.Success + "]" + ",Message=[" + rv.Message + "]";

                                }
                                else if (email.Format == WechatFormat.TEXT)
                                {
                                    ReturnValue rv = _co_WECHAT_NOTIBO.SendText(noti.AgentID.Value, email.EmailContent, noti.ID.Value.ToString(), false);
                                    email.ErrorMsg = "SendText: Success=[" + rv.Success + "]" + ",Message=[" + rv.Message + "]";
                                }
                                else if (email.Format == WechatFormat.QRCODE)
                                {
                                    Content cnt = this.GetSplitEmailContent(email.EmailContent);
                                    ReturnValue rv = new ReturnValue();
                                    if (!string.IsNullOrEmpty(cnt.BodyContent))
                                    {
                                        rv = _co_WECHAT_NOTIBO.SendText(noti.AgentID.Value, cnt.BodyContent, noti.ID.Value.ToString(), false);
                                        email.ErrorMsg = "SendText: Success=[" + rv.Success + "]" + ",Message=[" + rv.Message + "]";
                                    }

                                    if (rv.Success)
                                    {
                                        if (!string.IsNullOrEmpty(cnt.QrContent))
                                        {
                                            rv = _co_WECHAT_NOTIBO.SendImage(noti.AgentID.Value, email.EmailSubject, cnt.QrContent, noti.ID.Value.ToString(), false);
                                            email.ErrorMsg = "SendQRCode: Success=[" + rv.Success + "]" + ",Message=[" + rv.Message + "]";
                                        }
                                    }
                                }
                            }
                        }
                    }

                    email.SentCnt += 1;

                    //
                    email.ModifiedOn = DateTime.Now;
                    _co_BSC_EMAILBO.UpdateSome(email);
                }
                #endregion
                //
                if (!string.IsNullOrEmpty(returnMessage))
                {
                    _mesLog.LogException("Exception: " + returnMessage, this.Name + ".Execute()", true);
                }
                //
                if (_co_LES_TIMER != null)
                {
                    _co_LES_TIMER.LastTimestamp = Siemens.Simatic.Util.Utilities.DAO.UtilDAO.GetDatabaseUtcDatetime().Value.AddHours(8);
                    _co_LES_TIMERBO.UpdateSome(_co_LES_TIMER);
                }
            }
            catch (Exception ex)
            {
                _mesLog.LogException(ex.Message + Environment.NewLine + ex.StackTrace, this.Name + ".Execute()", true);
            }
            //
            return true;
        }
        #region SendNetMail

        /// <summary>
        /// send net mail
        /// </summary>
        /// <param name="to"></param>
        /// <param name="subject"></param>
        /// <param name="body">message</param>
        /// <param name="EnableSsl">use ssl. true for default. please set false for byd.</param>
        /// <returns></returns>
        public bool SendNetMail(string to, string subject, string body, IList<string> attachments, bool EnableSsl)
        {
            return MailHelper.SendNetMail(to, subject, body, attachments, this.SenderName, this.SenderUser, this.SenderPassword, this.SmtpServer, this.SmtpPort, EnableSsl);
        }

        /// <summary>
        /// send net mail
        /// </summary>
        /// <param name="to"></param>
        /// <param name="cc"></param>
        /// <param name="bcc"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        /// <param name="EnableSsl">use ssl. true for default. please set false for byd.</param>
        /// <returns></returns>
        public bool SendNetMail(string to, string cc, string bcc, string subject, string body, string attachments, bool EnableSsl)
        {
            return MailHelper.SendNetMail(to, cc, bcc, subject, body, attachments, this.SenderName, this.SenderUser, this.SenderPassword, this.SmtpServer, this.SmtpPort, EnableSsl);
        }

        /// <summary>
        /// send net mail
        /// </summary>
        /// <param name="toList"></param>
        /// <param name="ccList"></param>
        /// <param name="bccList"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        /// <param name="EnableSsl">use ssl. true for default. please set false for byd.</param>
        /// <returns></returns>
        public bool SendNetMail(IList<string> toList, IList<string> ccList, IList<string> bccList, string subject, string body, IList<string> attachments, bool EnableSsl)
        {
            return MailHelper.SendNetMail(toList, ccList, bccList, subject, body, attachments, this.SenderName, this.SenderUser, this.SenderPassword, this.SmtpServer, this.SmtpPort, EnableSsl);
        }

        #endregion

        #region 分离Body和QR的部分,用$$$分隔

        private Content GetSplitEmailContent(string emailContent)
        {
            Content cnt = new Content();
            int index = emailContent.IndexOf("$$$");
            if (index < 0)
            {
                cnt.BodyContent = emailContent;
            }
            else
            {
                cnt.BodyContent = emailContent.Substring(0, index);
                cnt.QrContent = emailContent.Substring(index + 3, emailContent.Length - index - 3);
            }

            return cnt;
        }


        #endregion


    }

    public class Content
    {
        private string bodyContent;
        private string qrContent;

        public string BodyContent
        {
            get { return bodyContent; }
            set { bodyContent = value; }
        }

        public string QrContent
        {
            get { return qrContent; }
            set { qrContent = value; }
        }
    }
}
