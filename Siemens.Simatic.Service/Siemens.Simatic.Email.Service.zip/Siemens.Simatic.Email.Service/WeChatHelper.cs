﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Siemens.Simatic.Email.Service
{
    public class WeChatHelper
    {

    }
}
