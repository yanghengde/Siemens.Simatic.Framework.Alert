﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Threading;
using System.Data;

using Siemens.Simatic.Platform.Core;
using Siemens.Simatic.Platform.Common;
using Siemens.Simatic.KPI.Common;
using Siemens.Simatic.KPI.BusinessLogic;

namespace Siemens.Simatic.Email.Service
{
    public abstract class MainService : IService
    {
        protected ICO_LES_TIMERBO _co_LES_TIMERBO;
        protected CO_LES_TIMER _co_LES_TIMER;

        protected TimeSpan _loopPeriod; 
        protected bool _loopFlag = true;
        protected IList<DateTime> _fixedTimers; 

        protected string _name;
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        protected MesLog _mesLog;
        public MesLog MesLog
        {
            get { return _mesLog; }
            set { _mesLog = value; }
        }

        public MainService(MesLog mesLog)
            : this("MesService", mesLog)
        {
        }

        public MainService(string name, MesLog mesLog)
        {
            Name = name;
            _mesLog = mesLog;
            //
            _co_LES_TIMERBO = ObjectContainer.BuildUp<ICO_LES_TIMERBO>();
            //
            _co_LES_TIMER = _co_LES_TIMERBO.GetEntity(name);
            if (_co_LES_TIMER == null)
            {
                _loopPeriod = new TimeSpan(0, 0, 300);
            }
            else
            {
                if (_co_LES_TIMER.TimerInterval.HasValue)
                {
                    _loopPeriod = new TimeSpan(0, 0, _co_LES_TIMER.TimerInterval.Value);
                }
                else if (!string.IsNullOrEmpty(_co_LES_TIMER.FixedTimers))
                {
                    _fixedTimers = new List<DateTime>();
                    foreach (string fixedTimer in _co_LES_TIMER.FixedTimers.Split(','))
                    {
                        if (string.IsNullOrEmpty(fixedTimer.Trim())) continue;
                        //
                        _fixedTimers.Add(Convert.ToDateTime(string.Format("2000-01-01 {0}:00", fixedTimer.Trim())));
                    }
                    //
                    _loopPeriod = new TimeSpan(0, 0, 60);
                }
                else
                {
                    _loopPeriod = new TimeSpan(0, 0, 300);
                }
            }
        }

        protected abstract object GetReadyData();
        protected abstract bool Execute(object readyData);

        public virtual bool DoService()
        {
            object readyData = this.GetReadyData();
            if (readyData != null)
            {
                try
                {
                    this.Execute(readyData);
                }
                finally
                {
                    GC.Collect();
                }
            }
            //
            return true;
        }

        public virtual void Start()
        {
            //1.log start process
            _mesLog.LogInfo("***** " + this.Name + " thread started! *****");

            //2.loop to upload
            _loopFlag = true;
            while (_loopFlag)
            {
                try
                {
                    if (_co_LES_TIMER != null && !_co_LES_TIMER.TimerInterval.HasValue && !string.IsNullOrEmpty(_co_LES_TIMER.FixedTimers))
                    {
                        if (_fixedTimers != null)
                        {
                            DateTime curTime = Siemens.Simatic.Util.Utilities.DAO.UtilDAO.GetDatabaseUtcDatetime().Value.AddHours(8);
                            foreach (DateTime fixedTime in _fixedTimers)
                            {
                                if (fixedTime.Hour == curTime.Hour && fixedTime.Minute == curTime.Minute)
                                {
                                    if (this.DoService())
                                    {
                                        _mesLog.LogInfo(this.Name + " processed one round completely.");
                                    }
                                    //
                                    break;
                                }
                            }
                            //
                            Thread.Sleep(_loopPeriod);
                        }
                        else
                        {
                            Thread.Sleep(_loopPeriod);
                        }
                    }
                    else if (this.DoService())
                    {
                        _mesLog.LogInfo(this.Name + " processed one round completely.");
                        Thread.Sleep(_loopPeriod);
                    }
                    //else
                    //{
                    //    Thread.Sleep(_loopPeriod);
                    //}
                }
                catch (Exception ex)
                {
                    _mesLog.LogException(ex.Message + Environment.NewLine + ex.StackTrace, this.Name + ".DoService");
                }
            }

            // time to end the thread
            if (Thread.CurrentThread.ThreadState != ThreadState.Aborted)
            {
                Thread.CurrentThread.Abort();
                _mesLog.LogInfo("***** " + this.Name + " thread to abort! *****");
            }
        }

        public virtual void Stop()
        {
            _loopFlag = false;

            //1.log stop process
            _mesLog.LogInfo("***** " + this.Name + " to stop! *****");
        }
    }
}
